Search and replace globally on 

djangoplicity-contacts -> djangoplicity-<appname>
djangoplicity.contacts -> djangoplicity.<appname>
djangoplicity.contacts -> djangoplicity/<appname>

Rename folders 
src/djangoplicity.contacts/static/apptemplate -> src/djangoplicity.contacts/static/<appname>
src/djangoplicity.contacts/static/templates -> src/djangoplicity.contacts/templates/<appname> 